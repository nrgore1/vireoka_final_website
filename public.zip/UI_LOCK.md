UI LOCK RULES – VIREOKA

1. Production UI is the canonical reference.
2. Dev must never change layout, spacing, or hierarchy without approval.
3. All landing-page changes must be visual diffs against production.
4. No conditional rendering on public pages.
5. Investor UI changes must be additive only.

Violation of these rules blocks merge to production.
