// Stub DB client
// Prisma is intentionally disabled until DB wiring is finalized.

// Keep this export name to satisfy existing imports
export const prisma = null;
