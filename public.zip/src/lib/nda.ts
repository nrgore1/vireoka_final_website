export const CURRENT_NDA_VERSION = 1;
export const INVITE_TTL_HOURS = 72; // invite link expires after 72 hours
