-- Temporarily disable all triggers on investor_applications
alter table investor_applications disable trigger all;
