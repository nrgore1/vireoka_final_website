select relrowsecurity
from pg_class
where relname = 'investor_applications';
