alter table investor_applications
alter column status set default 'submitted';
