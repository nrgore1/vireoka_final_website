alter table investor_applications disable row level security;
