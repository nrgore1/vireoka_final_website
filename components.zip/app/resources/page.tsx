import Link from "next/link";

export default function ResourcesPage() {
  return (
    <div>
      <div className="badge">Resources</div>
      <h1 className="h1">Confidence-building materials (public-safe).</h1>
      <p className="p">
        These resources explain our positioning and trust posture at a high level.
        Detailed product demos and deeper documentation are available only under NDA.
      </p>

      <div className="grid">
        <div className="card">
          <h3>Public Whitepaper</h3>
          <p>
            A non-confidential overview of Cognitive Governance, why it matters, and how it benefits enterprises.
          </p>
          <div style={{ marginTop: 10 }}>
            <Link className="btnSecondary" href="/resources/public-whitepaper">Read</Link>
          </div>
        </div>

        <div className="card">
          <h3>Responsible AI / Ethics Charter (Public)</h3>
          <p>
            Our trust-first commitments: safety, transparency, scope limits, and controlled disclosure.
          </p>
          <div style={{ marginTop: 10 }}>
            <Link className="btnSecondary" href="/resources/ethics-charter">Read</Link>
          </div>
        </div>

        <div className="card">
          <h3>Investor Access</h3>
          <p>
            Request NDA-gated access to the investor demo and deeper materials.
          </p>
          <div style={{ marginTop: 10 }}>
            <Link className="btn" href="/investors">Go to Investors</Link>
          </div>
        </div>

        <div className="card">
          <h3>Teaser Videos</h3>
          <p>
            30-second public teasers designed for trust and clarity (no IP leakage).
          </p>
          <div style={{ marginTop: 10 }}>
            <Link className="btnSecondary" href="/resources/teasers">View scripts</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
