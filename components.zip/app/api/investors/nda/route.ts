import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { readFile } from "fs/promises";
import path from "path";
import { getInvestorFromCookie } from "@/lib/investorAuth";

function bad(msg: string, status = 400) {
  return NextResponse.json({ ok: false, error: msg }, { status });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body) return bad("Invalid JSON.");

  const email = String(body.email || "").trim().toLowerCase();
  const accept = Boolean(body.accept);

  if (!email || !accept) return bad("Email + accept=true required.");

  const app = await prisma.investorApplication.findUnique({ where: { email } });
  if (!app) return bad("Application not found.");

  const ip = (req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || "").split(",")[0].trim();

  await prisma.investorApplication.update({
    where: { email },
    data: {
      status: app.status === "APPROVED" ? "APPROVED" : "NDA_ACCEPTED",
      ndaAcceptedAt: app.ndaAcceptedAt ?? new Date(),
      ndaAcceptedIp: ip || app.ndaAcceptedIp || null,
    },
  });

  return NextResponse.json({ ok: true });
}

// GET used only for NDA-gated downloads (server-side gated)
export async function GET(req: Request) {
  const url = new URL(req.url);
  const doc = url.searchParams.get("doc");

  if (doc !== "investor_whitepaper") {
    return bad("Unknown document.", 404);
  }

  const investor = await getInvestorFromCookie();
  if (!investor) {
    return bad("Not authorized.", 401);
  }

  const fp = path.join(process.cwd(), "docs/whitepapers-investor/VIREOKA_INVESTOR_WHITEPAPER_NDA.md");
  const content = await readFile(fp, "utf8");

  return new NextResponse(content, {
    headers: {
      "content-type": "text/markdown; charset=utf-8",
      "content-disposition": 'attachment; filename="VIREOKA_INVESTOR_WHITEPAPER_NDA.md"',
      "cache-control": "no-store",
    },
  });
}
