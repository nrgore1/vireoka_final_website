# Vireoka — Decision Ledger (Authoritative)

This file is the single source of truth for naming, positioning, and sharing rules.
Any future changes MUST be added here with a new entry, never by silent drift.

---

## D-0001 — External vs Internal Naming
**Status:** ACTIVE  
**Decision:** External product name is **Vireoka**. Internal codename is **AtmaSphere** and must never appear in public-facing materials.  
**Rationale:** Clear market brand + internal engineering continuity.  
**Scope:** Website, docs, UI, whitepapers, sales materials.

---

## D-0002 — Banned Term: "Decision Management"
**Status:** ACTIVE  
**Decision:** Do not use the term **Decision Management** anywhere in public or investor content.  
**Replacement terms (approved):**
- **Cognitive Governance** (default positioning)
- **Deliberative Intelligence** (technical contexts)
- **Intelligence Stewardship** (ethics/trust contexts)
- **Reasoning Governance** (compliance/explainability contexts)
- **Strategic Intelligence Fabric** (platform/CTO contexts)
**Rationale:** “Decision management” is transactional/rules-based; Vireoka is governance of reasoning.

---

## D-0003 — IP Safety + NDA Gate
**Status:** ACTIVE  
**Decision:** Anything that could reveal implementation details, council composition logic, scoring math, key management, architecture diagrams, UI internals, or workflow mechanics must be **NDA-gated**.  
**Public content may include:**
- High-level benefits
- High-level categories of capabilities
- Trust principles (auditability, accountability, explainability) without revealing mechanisms
**Investor content (NDA) may include:**
- Product demo access
- UI walkthroughs with controlled screenshots
- Deeper technical narrative, still avoiding code-level disclosure

---

## D-0004 — Investor Flow Requirements
**Status:** ACTIVE  
**Decision:** Investor access must be:
1) Application (email + org + intent)
2) NDA acceptance (tracked)
3) Manual approval (admin)
4) Time-bound access (expiry)
5) Revocable at any time
**Rationale:** Prevent leakage while supporting diligence.

---

## D-0005 — Public Website Sections (Approved)
**Status:** ACTIVE  
**Decision:** Public website includes:
- Home (high-level narrative)
- About (mission, trust posture)
- Resources (public whitepaper + ethics charter summary + safe materials)
- Investors (apply + NDA + gating)
**Rationale:** Confidence building without leaking confidential IP.

---

## D-0006 — WordPress Conversion Policy
**Status:** ACTIVE  
**Decision:** Next.js is the canonical content source. WordPress conversion occurs only after:
- Content freeze in Next.js
- Block mapping plan completed
- Public vs NDA content separation preserved
**Rationale:** Avoid drift and security regression.

---

## D-0007 — Content Tone
**Status:** ACTIVE  
**Decision:** Simple, compelling language. No jargon-heavy claims. No claims of machine consciousness or guaranteed “super-intelligence.”  
**Rationale:** Scientific credibility + trust-first messaging.

