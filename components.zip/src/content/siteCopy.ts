export const siteCopy = {
  brand: {
    name: "Vireoka",
    tagline: "Cognitive Governance for AI you can trust.",
  },

  nav: [
    { href: "/", label: "Home" },
    { href: "/about", label: "About" },
    { href: "/resources", label: "Resources" },
    { href: "/investors", label: "Investors" },
  ],

  home: {
    heroTitle: "Cognitive Governance for high-stakes AI",
    heroSubtitle:
      "Vireoka helps organizations govern how AI reasons—so outputs are traceable, explainable, and accountable.",
    bullets: [
      "Govern reasoning with clear guardrails—not black-box outputs.",
      "Produce board-ready evidence trails without exposing sensitive internals.",
      "Support responsible deployment across regulated and high-risk environments.",
    ],
    ctaPrimary: { label: "Explore resources", href: "/resources" },
    ctaSecondary: { label: "Investor access (NDA)", href: "/investors" },

    sections: [
      {
        title: "What we mean by Cognitive Governance",
        body:
          "AI adoption breaks when systems can’t explain why a result happened or reproduce how it evolved. Cognitive Governance focuses on governing reasoning over time—so accountability is built in, not bolted on.",
      },
      {
        title: "Where this helps first",
        body:
          "Regulated workflows, board-level oversight, enterprise AI programs, and any environment where trust, auditability, and safety are non-negotiable.",
      },
      {
        title: "How we talk about it",
        body:
          "Depending on audience: Cognitive Governance (boards/regulators), Intelligence Stewardship (ethics/trust), Deliberative Intelligence (technical stakeholders).",
      },
    ],
  },

  about: {
    title: "About Vireoka",
    body: [
      "Vireoka is building a governance-first layer for modern AI systems.",
      "Our focus is not to replace human judgment—but to make AI reasoning safer to rely on: traceable, explainable, and accountable.",
      "We separate public education from confidential implementation. Sensitive mechanics stay private and are available only under NDA for qualified investors.",
    ],
    principlesTitle: "Operating principles",
    principles: [
      "Trust-first: explainability and accountability are default behaviors.",
      "Risk-aware: governance posture adapts to domain and stakes.",
      "No IP leakage: public content stays high-level by design.",
    ],
  },

  resources: {
    title: "Resources",
    publicWhitepaper: {
      title: "Public Whitepaper: Cognitive Governance (Public Edition)",
      description:
        "A public-safe overview of the problem, the governance approach, and how organizations evaluate trust in AI—without disclosing proprietary mechanisms.",
      href: "/resources/whitepaper",
    },
    ethicsCharter: {
      title: "Responsible AI & Ethics Charter (Public)",
      description:
        "A practical, non-performative charter for building and deploying AI responsibly.",
      href: "/resources/ethics",
    },
    teasers: {
      title: "30-second teasers (public-safe)",
      description:
        "Short scripts suitable for voiceover + motion graphics—trust-building, no confidential details.",
      href: "/resources/teasers",
    },
  },

  investors: {
    title: "Investor access (NDA required)",
    body: [
      "We provide an NDA-gated portal for qualified investors.",
      "Public pages intentionally avoid confidential implementation details.",
    ],
    steps: [
      "Apply for access",
      "Accept the NDA",
      "Await approval",
      "Access expires automatically",
    ],
    ctaApply: { label: "Apply", href: "/investors/apply" },
    ctaStatus: { label: "Check status", href: "/investors/status" },
    ctaPortal: { label: "Investor portal", href: "/investors/portal" },
  },

  footer: {
    disclaimer:
      "Vireoka provides governance tooling and educational material. Nothing on this website is legal, medical, or financial advice.",
    copyright: `© ${new Date().getFullYear()} Vireoka LLC`,
  },
} as const;
