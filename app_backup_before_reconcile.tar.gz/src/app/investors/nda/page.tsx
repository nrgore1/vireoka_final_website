"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

export default function InvestorNdaPage() {
  const sp = useSearchParams();
  const email = useMemo(() => sp.get("email") || "", [sp]);
  const [addr, setAddr] = useState(email);
  const [accepted, setAccepted] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [ok, setOk] = useState(false);

  async function submit() {
    setMsg(null);
    setOk(false);

    const res = await fetch("/api/investors/nda", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email: addr, ndaAccepted: accepted }),
    });

    const data = await res.json().catch(() => null);
    if (!res.ok || !data?.ok) {
      setMsg("Please confirm the NDA checkbox and use the same email you applied with.");
      return;
    }

    setOk(true);
    setMsg("NDA accepted. Your request is now pending review.");
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-3xl font-semibold tracking-tight">Non-Disclosure Agreement (NDA)</h1>
      <p className="text-sm text-neutral-700">
        This is a lightweight NDA acknowledgment for early-stage investor sharing. It confirms you will not disclose
        confidential materials shared via the investor portal.
      </p>

      <section className="rounded-lg border p-5 space-y-3">
        <div className="text-sm font-semibold">Email used for your application</div>
        <input
          className="w-full rounded-md border p-2"
          value={addr}
          onChange={(e) => setAddr(e.target.value)}
          placeholder="you@firm.com"
        />

        <label className="flex gap-3 items-start text-sm">
          <input
            type="checkbox"
            checked={accepted}
            onChange={(e) => setAccepted(e.target.checked)}
            className="mt-1"
          />
          <span className="text-neutral-700">
            I agree that any investor materials I receive are confidential, will be used only for evaluation, and will
            not be shared without written permission.
          </span>
        </label>

        <button
          onClick={submit}
          className="rounded-md bg-neutral-900 text-white px-4 py-2 text-sm hover:opacity-90"
          type="button"
          disabled={!addr || !accepted}
        >
          Accept NDA
        </button>

        {msg && <div className="text-sm text-neutral-700">{msg}</div>}

        {ok ? (
          <div className="text-sm">
            <Link className="underline underline-offset-4" href="/investors/status">
              Check status →
            </Link>
          </div>
        ) : null}
      </section>

      <p className="text-xs text-neutral-600">
        Note: For a formal signed NDA (PDF + e-sign), replace this step with your preferred workflow.
      </p>
    </div>
  );
}
