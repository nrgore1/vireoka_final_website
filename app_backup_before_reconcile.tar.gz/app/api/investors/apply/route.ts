import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

function bad(msg: string, status = 400) {
  return NextResponse.json({ ok: false, error: msg }, { status });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body) return bad("Invalid JSON.");

  const email = String(body.email || "").trim().toLowerCase();
  const fullName = String(body.fullName || "").trim();
  const org = String(body.org || "").trim();
  const role = String(body.role || "").trim();
  const intent = String(body.intent || "").trim();

  if (!email || !fullName || !org || !role || !intent) return bad("Missing required fields.");

  // Upsert application; preserve NDA acceptance/approval if already exists
  const existing = await prisma.investorApplication.findUnique({ where: { email } });

  if (!existing) {
    await prisma.investorApplication.create({
      data: { email, fullName, org, role, intent, status: "APPLIED" },
    });
  } else {
    // Only allow updating basic fields if not approved yet
    if (existing.status !== "APPROVED") {
      await prisma.investorApplication.update({
        where: { email },
        data: { fullName, org, role, intent },
      });
    }
  }

  return NextResponse.json({ ok: true });
}
