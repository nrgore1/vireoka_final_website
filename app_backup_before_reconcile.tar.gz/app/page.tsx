import Link from "next/link";

export default function HomePage() {
  return (
    <div>
      <div className="badge">Cognitive Governance • Deliberative Intelligence • Intelligence Stewardship</div>
      <h1 className="h1">Govern how AI reasons — before it shapes high-stakes outcomes.</h1>
      <p className="p">
        Vireoka helps organizations introduce AI responsibly by adding governance controls that make reasoning
        accountable, explainable, and reviewable — without exposing confidential internals on the public web.
      </p>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 14 }}>
        <Link className="btn" href="/resources">Explore resources</Link>
        <Link className="btnSecondary" href="/investors">Investor access</Link>
        <Link className="btnSecondary" href="/about">Why Vireoka</Link>
      </div>

      <div className="grid">
        <div className="card">
          <h3>Cognitive Governance</h3>
          <p>Oversight for high-stakes AI reasoning: accountability, traceability, and defensible outputs.</p>
        </div>
        <div className="card">
          <h3>Deliberative Intelligence</h3>
          <p>Structured deliberation instead of single-shot answers — improving clarity, trust, and consistency.</p>
        </div>
        <div className="card">
          <h3>Intelligence Stewardship</h3>
          <p>Trust-first posture: controlled access, auditability, and clear disclosure of uncertainty.</p>
        </div>
        <div className="card">
          <h3>Built for regulated reality</h3>
          <p>Designed for boards, compliance teams, and leadership — with investor materials gated by NDA.</p>
        </div>
      </div>

      <hr className="hr" />

      <h2 className="h2">What you can expect</h2>
      <p className="p">
        Public materials stay intentionally high-level. If you are evaluating the platform for investment,
        you can request NDA access to view the demo and deeper documentation.
      </p>

      <p className="small">
        Tip: keep our naming consistent. Avoid banned terms. If anything drifts, update{" "}
        <span className="kbd">docs/decision-ledger/DECISION_LEDGER.md</span> first.
      </p>
    </div>
  );
}
