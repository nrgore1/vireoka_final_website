import { readPublicDoc } from "@/lib/publicDocs";

export default async function PublicWhitepaperPage() {
  const md = await readPublicDoc("docs/whitepapers-public/VIREOKA_PUBLIC_WHITEPAPER.md");
  return (
    <div>
      <div className="badge">Public Whitepaper</div>
      <h1 className="h1">Vireoka — Cognitive Governance (Public Overview)</h1>
      <article className="small" style={{ whiteSpace: "pre-wrap" }}>{md}</article>
    </div>
  );
}
