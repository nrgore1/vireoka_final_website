import { readPublicDoc } from "@/lib/publicDocs";

export default async function TeasersPage() {
  const md = await readPublicDoc("docs/video/VIREOKA_30S_TEASER_SCRIPTS.md");
  return (
    <div>
      <div className="badge">Teasers</div>
      <h1 className="h1">30-second public teaser scripts</h1>
      <article className="small" style={{ whiteSpace: "pre-wrap" }}>{md}</article>
    </div>
  );
}
