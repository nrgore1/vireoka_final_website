import { readPublicDoc } from "@/lib/publicDocs";

export default async function EthicsCharterPage() {
  const md = await readPublicDoc("docs/whitepapers-public/VIREOKA_PUBLIC_ETHICS_CHARTER.md");
  return (
    <div>
      <div className="badge">Responsible AI / Ethics Charter</div>
      <h1 className="h1">Responsible AI / Ethics Charter (Public)</h1>
      <article className="small" style={{ whiteSpace: "pre-wrap" }}>{md}</article>
    </div>
  );
}
