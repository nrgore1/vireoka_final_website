import "./globals.css";
import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Vireoka — Cognitive Governance for High-Stakes AI",
  description:
    "Vireoka provides Cognitive Governance: oversight, accountability, and trust controls for high-stakes AI-assisted reasoning.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="header">
          <div className="container headerRow">
            <Link className="logo" href="/">Vireoka</Link>
            <nav className="nav">
              <Link href="/about">About</Link>
              <Link href="/resources">Resources</Link>
              <Link href="/investors">Investors</Link>
            </nav>
          </div>
        </header>

        <main className="container main">{children}</main>

        <footer className="footer">
          <div className="container footerRow">
            <div className="muted">© {new Date().getFullYear()} Vireoka LLC</div>
            <div className="muted">
              Public site content is intentionally high-level. Investor materials require NDA approval.
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
