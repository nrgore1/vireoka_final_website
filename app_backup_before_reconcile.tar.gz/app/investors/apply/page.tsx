"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function InvestorApplyPage() {
  const r = useRouter();
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErr(null);
    setLoading(true);

    const fd = new FormData(e.currentTarget);
    const payload = Object.fromEntries(fd.entries());

    const res = await fetch("/api/investors/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json().catch(() => ({}));
    setLoading(false);

    if (!res.ok) {
      setErr(data?.error || "Unable to submit. Please try again.");
      return;
    }

    r.push(`/investors/nda?email=${encodeURIComponent(String(payload.email || ""))}`);
  }

  return (
    <div>
      <div className="badge">Investor Application</div>
      <h1 className="h1">Apply for NDA-gated access</h1>
      <p className="p">This request is reviewed manually. Access is time-limited after approval.</p>

      <form onSubmit={onSubmit}>
        <label className="label">Email</label>
        <input name="email" type="email" className="input" required />

        <label className="label">Full name</label>
        <input name="fullName" className="input" required />

        <label className="label">Organization</label>
        <input name="org" className="input" required />

        <label className="label">Role</label>
        <input name="role" className="input" required />

        <label className="label">Intent (why you want access)</label>
        <textarea name="intent" className="input" rows={4} required />

        {err ? <p className="small" style={{ color: "#ffb4b4" }}>{err}</p> : null}

        <div style={{ marginTop: 12, display: "flex", gap: 10, flexWrap: "wrap" }}>
          <button className="btn" disabled={loading}>
            {loading ? "Submitting..." : "Continue to NDA"}
          </button>
          <a className="btnSecondary" href="/investors">Back</a>
        </div>
      </form>
    </div>
  );
}
