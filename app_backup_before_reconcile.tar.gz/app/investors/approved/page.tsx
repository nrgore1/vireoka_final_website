"use client";

import { useEffect, useState } from "react";

export default function InvestorApprovedPage() {
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  async function enter() {
    setMsg(null);
    const res = await fetch("/api/investors/status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, issueAccessToken: true }),
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setMsg(data?.error || "Unable to continue.");
      return;
    }
    if (data.ok && data.status === "APPROVED") {
      window.location.href = "/investors/demo";
    } else {
      setMsg("Not approved or expired. Please check status.");
    }
  }

  return (
    <div>
      <div className="badge">Approved Access</div>
      <h1 className="h1">Enter the investor demo</h1>
      <p className="p">
        For security, we verify approval and set an access cookie. Access is time-bound and revocable.
      </p>

      <label className="label">Email</label>
      <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} />

      <div style={{ marginTop: 12 }}>
        <button className="btn" onClick={enter}>Enter demo</button>
        <a className="btnSecondary" style={{ marginLeft: 10 }} href="/investors">Back</a>
      </div>

      {msg ? <p className="small" style={{ color: "#ffb4b4" }}>{msg}</p> : null}
    </div>
  );
}
