import { Suspense } from "react";
import InvestorNdaClient from "./NdaClient";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Investor NDA",
};

export default function InvestorNdaPage() {
  return (
    <Suspense fallback={<div style={{ padding: 16 }}>Loading…</div>}>
      <InvestorNdaClient />
    </Suspense>
  );
}
