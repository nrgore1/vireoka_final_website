update investor_applications
set status = 'submitted'
where status = 'pending';
