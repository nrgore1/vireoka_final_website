export const investorTabs = [
  { key: "overview", label: "Overview" },
  { key: "demo", label: "Live Demo" },
  { key: "overview-docs", label: "Product Walkthrough" },
];
