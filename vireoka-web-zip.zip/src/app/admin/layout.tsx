import { ReactNode } from "react";
import { redirect } from "next/navigation";
import { getServerSupabase } from "@/lib/supabase/serverClients";
import { isAdminUser } from "@/lib/auth/isAdminUser";

export default async function AdminLayout({
  children,
}: {
  children: ReactNode;
}) {
  const supabase = getServerSupabase();
  const {
    data: { session },
  } = await supabase.auth.getSession();

  if (!session) redirect("/login");

  const adminCheck = await isAdminUser(session.user.id);
  if (!adminCheck) redirect("/");

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="border-b bg-white p-4 font-semibold">
        Admin Dashboard
      </header>
      <main className="p-6">{children}</main>
    </div>
  );
}
