declare module "nodemailer" {
  const nodemailer: any;
  export default nodemailer;
}
