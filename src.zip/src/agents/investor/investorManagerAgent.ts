import { getNdaStatus } from "@/agents/nda/ndaAgent";
import { getTermsStatus } from "@/agents/terms/termsAgent";
import { getSessionUser } from "@/lib/auth/session";
import { getLeadByEmail } from "@/repo/investorLeadsRepo";

export type AccessState =
  | "logged_out"
  | "pending_approval"
  | "nda_missing"
  | "terms_missing"
  | "role_denied"
  | "allowed";

export async function accessCheck(): Promise<{ ok: boolean; state: AccessState; role: string | null }> {
  const user = await getSessionUser();
  if (!user?.email) return { ok: false, state: "logged_out", role: null };

  const lead = await getLeadByEmail(user.email);
  const status = String(lead?.status || "").toUpperCase();
  const role = (lead?.investor_type ?? null) as string | null;

  if (status !== "APPROVED") return { ok: false, state: "pending_approval", role };

  const nda = await getNdaStatus();
  if (nda.status !== "accepted") return { ok: false, state: "nda_missing", role };

  const terms = await getTermsStatus();
  if (terms.status !== "accepted") return { ok: false, state: "terms_missing", role };

  if (!role) return { ok: false, state: "role_denied", role: null };
  return { ok: true, state: "allowed", role };
}
