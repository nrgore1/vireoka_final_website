import { sendEmail } from "@/lib/email/sendEmail";

export async function sendRequestInfoEmail(args: { email: string; statusUrl: string }) {
  const to = String(args.email || "").trim().toLowerCase();
  const statusUrl = String(args.statusUrl || "").trim();

  const subject = "We need more information to proceed";

  const html = `
    <div style="font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial; line-height: 1.5;">
      <h2 style="margin: 0 0 12px;">We need more information</h2>
      <p style="margin: 0 0 12px;">
        Thanks for your interest. We need a bit more information to proceed with your investor access request.
      </p>
      <p style="margin: 0 0 12px;">
        Please check your application status and provide the requested details here:
      </p>
      <p style="margin: 0 0 18px;">
        <a href="${statusUrl}" style="display: inline-block; padding: 10px 14px; border-radius: 10px; background: #111827; color: #ffffff; text-decoration: none; font-weight: 700;">
          View Status
        </a>
      </p>
      <p style="margin: 0; color: #6b7280; font-size: 12px;">
        If the button doesn’t work, copy and paste this URL into your browser:<br/>
        ${statusUrl}
      </p>
    </div>
  `;

  await sendEmail({
    to,
    subject,
    html,
  });
}
