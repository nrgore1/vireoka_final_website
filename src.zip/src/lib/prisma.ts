/**
 * Prisma is intentionally disabled.
 * This stub exists to prevent accidental imports.
 * 
 * When enabling Prisma later:
 *  - Install @prisma/client
 *  - Generate client
 *  - Replace this file
 */

export const prisma = null as never;
