export const TERMS_VERSION =
  process.env.NEXT_PUBLIC_TERMS_VERSION?.trim() || "2026-02-24";

export const NDA_VERSION =
  process.env.NEXT_PUBLIC_NDA_VERSION?.trim() || "2026-02-24";
