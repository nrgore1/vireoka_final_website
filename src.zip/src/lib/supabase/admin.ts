import { createClient } from "@supabase/supabase-js";

export function supabaseAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL;
  const service = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url) throw new Error("Missing SUPABASE URL");
  if (!service) throw new Error("Missing SUPABASE_SERVICE_ROLE_KEY");

  return createClient(url, service, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

// Simple header-token guard (for curl + internal admin tools)
export function requireAdminToken(req: Request): boolean {
  const expected = process.env.ADMIN_TOKEN || process.env.ADMIN_API_TOKEN || "";
  if (!expected) return false;
  const got = req.headers.get("x-admin-token") || "";
  return got === expected;
}

export function requireAdminTokenOrThrow(req: Request) {
  if (!requireAdminToken(req)) {
    throw new Error("unauthorized");
  }
}
