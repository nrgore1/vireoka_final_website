export const investorTabs = [
  { label: "Overview", href: "/investors" },
  { label: "Platform Walkthrough", href: "/investors/figma" },
];
