import { redirect } from "next/navigation";

export default function InvestorsCatchallRedirect() {
  redirect("/intelligence");
}
