export default function NotAuthorized() {
  return (
    <div style={{ padding: 24, fontFamily: "system-ui" }}>
      <h1>Not authorized</h1>
      <p>You do not have access to this page.</p>
    </div>
  );
}
