export const investorTabs = [
  { label: "Overview", href: "/intelligence" },
  { label: "Platform Walkthrough", href: "/intelligence/figma" },
];
