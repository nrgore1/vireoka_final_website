import Link from "next/link";
import { CTABar } from "@/components/CTABar";
import { ArchitectureDiagram } from "@/components/ArchitectureDiagram";

const RoleLink = ({ href, title, desc }: { href: string; title: string; desc: string }) => (
  <Link
    href={href}
    className="rounded-2xl border border-gray-200 bg-white p-5 hover:bg-gray-50 transition"
  >
    <div className="text-sm font-semibold text-gray-900">{title}</div>
    <div className="mt-1 text-sm text-gray-700">{desc}</div>
  </Link>
);

export default function IntelligenceOverview() {
  return (
    <main className="mx-auto max-w-6xl px-6 py-16 space-y-12">
      <section className="space-y-5">
        <h1 className="text-4xl font-bold text-vireoka-indigo">Vireoka Intelligence</h1>
        <p className="text-lg text-gray-700">
          Vireoka builds governance-native agentic infrastructure: digital employees that operate within defined authority,
          policy constraints, and audit-native execution. This is not generic AI tooling—this is runtime governance for delegation.
        </p>

        <CTABar
          primaryHref="/intelligence/portal"
          primaryLabel="Open Portal (if approved)"
          secondaryHref="/intelligence/request-access"
          secondaryLabel="Request Access"
        />
      </section>

      <ArchitectureDiagram />

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-gray-900">Digital Employees</h2>
        <p className="text-gray-700">
          We deploy domain-specialized agents as digital employees, governed by a shared runtime:
          authority envelopes, pre-execution enforcement, escalation logic, and immutable audit.
        </p>
        <ul className="list-disc pl-6 text-gray-700 space-y-2">
          <li><strong>Agent Kairo</strong> — Infrastructure orchestration</li>
          <li><strong>Agent Angelo</strong> — Design systems management</li>
          <li><strong>Agent Cody</strong> — Code quality & architecture governance</li>
          <li><strong>Agent Vire</strong> — Website development and delivery</li>
          <li><strong>Agent Viral</strong> — Marketing systems and demand orchestration</li>
          <li><strong>Agent Stable</strong> — StableStack proving module (policy-constrained capital delegation)</li>
        </ul>

        <div className="pt-2">
          <Link href="/intelligence/stablestack" className="text-sm font-semibold text-vireoka-indigo hover:underline">
            Explore StableStack proving module →
          </Link>
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-gray-900">Explore by Role</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <RoleLink href="/intelligence/advisors" title="Advisors" desc="Help shape governance primitives, deployment models, and category standards." />
          <RoleLink href="/intelligence/angels" title="Angels" desc="Early conviction: governance control plane for digital workforces, proven via modules like StableStack." />
          <RoleLink href="/intelligence/vc" title="VCs" desc="Infrastructure thesis, expansion path, and control-plane economics for governed delegation." />
          <RoleLink href="/intelligence/partners" title="Partners" desc="Integration pathways, co-development, and standards participation." />
          <RoleLink href="/intelligence/contributors" title="Contributors" desc="Research, engineering, and governance systems building—digital employees require restraint architecture." />
        </div>
      </section>
    </main>
  );
}
