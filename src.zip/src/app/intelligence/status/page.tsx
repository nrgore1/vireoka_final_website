import InvestorStatusClient from "./statusClient";

export const metadata = {
  title: "Check Application Status",
};

export default function InvestorStatusPage() {
  return <InvestorStatusClient />;
}
