"use client";

import { useState } from "react";
import { NDA_VERSION } from "@/lib/legal";
import { CONTACT_EMAIL, CONTACT_MAILTO } from "@/lib/contact";

export default function NDAPage() {
  const [saving, setSaving] = useState(false);

  async function accept() {
    setSaving(true);
    try {
      await fetch("/api/legal/nda/accept", { method: "POST", credentials: "include" });
      window.location.href = "/intelligence/access-check";
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="mx-auto max-w-3xl px-6 py-12">
      <a className="text-sm font-semibold text-neutral-700 hover:underline" href="/intelligence">
        ← Back to Intelligence
      </a>

      <h1 className="mt-4 text-3xl font-semibold tracking-tight text-neutral-900">
        Non-Disclosure Agreement
      </h1>

      <p className="mt-4 text-sm text-neutral-600">Version: {NDA_VERSION}</p>

      <div className="mt-8 rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
        <p className="text-sm leading-6 text-neutral-700">
          The materials in the private workspace are confidential. By accepting, you agree:
        </p>

        <ul className="mt-4 list-disc space-y-2 pl-5 text-sm leading-6 text-neutral-700">
          <li>Not to disclose confidential materials to third parties.</li>
          <li>Not to copy, redistribute, or publish restricted content.</li>
          <li>To use the materials only for evaluation and agreed collaboration.</li>
          <li>To comply with role-based access limits and security guidelines.</li>
        </ul>

        <div className="mt-6 flex flex-wrap gap-3">
          <button
            onClick={accept}
            disabled={saving}
            className="rounded-xl border border-neutral-200 bg-neutral-900 px-4 py-2 text-sm font-semibold text-white"
          >
            {saving ? "Saving…" : "I Accept — Continue"}
          </button>

          <a
            className="rounded-xl border border-neutral-200 bg-white px-4 py-2 text-sm font-semibold text-neutral-900"
            href={CONTACT_MAILTO}
          >
            Questions? Email {CONTACT_EMAIL}
          </a>
        </div>

        <p className="mt-4 text-xs text-neutral-600">
          For formal e-signature workflows, contact us and we’ll provide a signing link.
        </p>
      </div>
    </main>
  );
}
