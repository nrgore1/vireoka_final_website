'use client';

export default function ClientMarker() {
  return null;
}
