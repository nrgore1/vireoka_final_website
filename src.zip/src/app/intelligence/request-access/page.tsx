import Link from "next/link";
import { CTABar } from "@/components/CTABar";

export default function RequestAccessPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-16 space-y-8">
      <h1 className="text-3xl font-bold text-vireoka-indigo">Request Portal Access</h1>
      <p className="text-gray-700">
        The Vireoka Intelligence Portal is gated. Access is granted to advisors, investors, partners,
        and select contributors evaluating the governance runtime and digital employee framework.
      </p>

      <div className="rounded-2xl border border-gray-200 bg-white p-6 space-y-3">
        <div className="text-sm font-semibold text-gray-900">How to get access</div>
        <ol className="list-decimal pl-6 text-gray-700 space-y-2">
          <li>Submit the request-access form.</li>
          <li>Once approved, the server sets an httpOnly investor session cookie.</li>
          <li>Return to the portal — no ModHeader or manual headers required.</li>
        </ol>

        <CTABar
          primaryHref="/intelligence"
          primaryLabel="View Public Intelligence"
          secondaryHref="/"
          secondaryLabel="Back to Home"
        />
      </div>

      <p className="text-sm text-gray-600">
        If you already have access, visit{" "}
        <Link href="/intelligence/portal" className="font-semibold text-vireoka-indigo hover:underline">
          /intelligence/portal
        </Link>.
      </p>
    </main>
  );
}
