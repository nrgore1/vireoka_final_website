import { NextResponse } from "next/server";
import { z } from "zod";
import { createAdminSessionCookie } from "@/lib/adminSession";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const Body = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export async function POST(req: Request) {
  try {
    const body = Body.parse(await req.json());

    const expectedEmail = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
    const expectedPass = process.env.INVESTOR_ADMIN_PASSWORD || "";

    if (!expectedEmail || !expectedPass) {
      return NextResponse.json(
        { ok: false, error: "Admin env not configured (ADMIN_EMAIL / INVESTOR_ADMIN_PASSWORD)" },
        { status: 500 }
      );
    }

    if (body.email.trim().toLowerCase() !== expectedEmail || body.password !== expectedPass) {
      return NextResponse.json({ ok: false, error: "Invalid admin credentials" }, { status: 401 });
    }

    const res = NextResponse.json({ ok: true }, { status: 200 });
    createAdminSessionCookie(res, { email: expectedEmail });
    return res;
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "Bad request" }, { status: 400 });
  }
}
