import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseAdmin, requireAdminTokenOrThrow } from "@/lib/supabase/admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const BodySchema = z.object({
  id: z.string().uuid(),
  status: z.enum(["NEW", "APPROVED", "REVOKED"]),
});

export async function POST(req: Request) {
  try {
    requireAdminTokenOrThrow(req);

    const json = await req.json().catch(() => null);
    const parsed = BodySchema.safeParse(json);
    if (!parsed.success) {
      return NextResponse.json({ ok: false, error: "Invalid request" }, { status: 400 });
    }

    const { id, status } = parsed.data;

    const sb = supabaseAdmin();

    // optional: enforce transition rules (simple + safe)
    const { data: existing, error: e0 } = await sb
      .from("investor_leads")
      .select("status")
      .eq("id", id)
      .single();

    if (e0 || !existing) {
      return NextResponse.json({ ok: false, error: "Lead not found" }, { status: 404 });
    }

    const prev = String(existing.status || "NEW").toUpperCase();
    const allowed =
      (prev === "NEW" && (status === "APPROVED" || status === "REVOKED")) ||
      (prev === "APPROVED" && status === "REVOKED") ||
      (prev === "REVOKED" && status === "REVOKED");

    if (!allowed) {
      return NextResponse.json(
        { ok: false, error: `Transition not allowed (${prev} → ${status})` },
        { status: 400 }
      );
    }

    const { error } = await sb
      .from("investor_leads")
      .update({ status, updated_at: new Date().toISOString() })
      .eq("id", id);

    if (error) {
      return NextResponse.json({ ok: false, error: "Update failed", detail: error.message }, { status: 500 });
    }

    return NextResponse.json({ ok: true, id, status }, { status: 200 });
  } catch (e: any) {
    if (String(e?.message || "").includes("unauthorized")) {
      return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });
    }
    return NextResponse.json({ ok: false, error: "Server error" }, { status: 500 });
  }
}
