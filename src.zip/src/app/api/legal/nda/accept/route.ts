import { NextResponse } from "next/server";
import { acceptNda } from "@/agents/nda/ndaAgent";
import { getSessionUser } from "@/lib/auth/session";
import { supabaseAdmin } from "@/lib/supabase/admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST() {
  const user = await getSessionUser();
  if (!user?.email) {
    return NextResponse.json({ ok: false, message: "Not authenticated" }, { status: 401 });
  }

  // Require APPROVED lead
  const supabase = supabaseAdmin();
  const { data: lead } = await supabase
    .from("investor_leads")
    .select("status")
    .eq("email", user.email.toLowerCase())
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!lead || lead.status !== "APPROVED") {
    return NextResponse.json(
      {
        ok: false,
        message: "Access pending approval. Please request access first, then wait for approval.",
        state: "pending_approval",
      },
      { status: 403 }
    );
  }

  await acceptNda();
  return NextResponse.json({ ok: true });
}
