# Vireoka — Decision & Design Ledger (Authoritative)

This document is the single source of truth for all
naming, architectural, branding, and exposure decisions.

If a decision appears here, it MUST NOT be revisited
unless explicitly deprecated in this file.

---

## D-001: Platform Naming
Status: FINAL

Decision:
- External platform name: Vireoka
- Company name: Vireoka LLC
- Internal codename: AtmaSphere (never referenced publicly)

Rationale:
- Neutral, global branding
- Low IP infringement probability
- Internal philosophical depth preserved without exposure

---

## D-002: Terminology Ban — “Decision Management”
Status: FINAL

Decision:
The term “Decision Management” is FORBIDDEN:
- In public content
- In investor materials
- In internal-facing UI labels
- In documentation

Approved replacements:
- Cognitive Governance (default, primary)
- Deliberative Intelligence (technical contexts)
- Intelligence Stewardship (ethics, public sector)

Rationale:
- “Decision Management” implies rules and transactions
- Vireoka governs reasoning, judgment, and deliberation

---

## D-003: External Positioning
Status: FINAL

Decision:
Vireoka is positioned as:
- A Cognitive Governance Platform
- Governance infrastructure for intelligence
- NOT a chatbot
- NOT an automation engine
- NOT a decision engine

Approved language:
- “We govern how intelligence reasons”
- “Explainable, auditable intelligence”
- “Governance-first AI”

---

## D-004: IP Exposure Policy
Status: FINAL

Public:
- Concepts
- Outcomes
- Governance benefits
- Trust narratives

Investor (NDA only):
- Governance UI demos (non-interactive)
- Conceptual lineage visuals
- Strategic positioning

Never Exposed:
- Internal council logic
- Reasoning weights
- Policy engines
- Cryptographic architecture
- AtmaSphere internals

---

## D-005: Website Content Rules
Status: FINAL

Public website:
- Simple language
- No architectural diagrams
- No internal terminology
- No council descriptions

Investor portal:
- NDA-gated
- Read-only demos
- No downloadable internals

---

## D-006: Regression Prevention Rule
Status: FINAL

If a term, feature, or concept is removed or renamed here:
- It must not reappear anywhere else
- All future work must conform to this ledger

