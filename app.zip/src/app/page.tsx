import Link from "next/link";
import { siteCopy } from "@/content/siteCopy";

export default function HomePage() {
  const c = siteCopy.home;

  return (
    <div className="space-y-12">
      <section className="space-y-4">
        <h1 className="text-4xl font-semibold tracking-tight">{c.heroTitle}</h1>
        <p className="text-lg text-neutral-700 max-w-2xl">{c.heroSubtitle}</p>

        <ul className="mt-6 space-y-2 text-neutral-800">
          {c.bullets.map((b) => (
            <li key={b} className="flex gap-2">
              <span aria-hidden>•</span>
              <span>{b}</span>
            </li>
          ))}
        </ul>

        <div className="flex gap-3 pt-4">
          <Link href={c.ctaPrimary.href} className="rounded-md border px-4 py-2 text-sm hover:bg-neutral-50">
            {c.ctaPrimary.label}
          </Link>
          <Link href={c.ctaSecondary.href} className="rounded-md bg-neutral-900 text-white px-4 py-2 text-sm hover:opacity-90">
            {c.ctaSecondary.label}
          </Link>
        </div>
      </section>

      <section className="grid gap-6 md:grid-cols-3">
        {c.sections.map((s) => (
          <div key={s.title} className="rounded-lg border p-5">
            <h2 className="font-semibold">{s.title}</h2>
            <p className="mt-2 text-sm text-neutral-700">{s.body}</p>
          </div>
        ))}
      </section>

      <section className="rounded-lg border p-6 bg-neutral-50">
        <h2 className="font-semibold">Public-safe by design</h2>
        <p className="mt-2 text-sm text-neutral-700 max-w-3xl">
          This website is intentionally high-level. Detailed implementation, demos, and deeper material are available only
          through the NDA-gated investor portal for qualified investors.
        </p>
        <div className="mt-4">
          <Link href="/investors" className="text-sm underline underline-offset-4">
            Investor access →
          </Link>
        </div>
      </section>
    </div>
  );
}
