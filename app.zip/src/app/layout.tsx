import "./globals.css";
import Link from "next/link";
import { siteCopy } from "@/content/siteCopy";

export const metadata = {
  title: "Vireoka — Cognitive Governance",
  description: "Cognitive Governance for high-stakes AI.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-white text-neutral-900">
        <header className="border-b">
          <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
            <Link href="/" className="font-semibold tracking-tight">
              {siteCopy.brand.name}
            </Link>
            <nav className="flex gap-4 text-sm">
              {siteCopy.nav.map((n) => (
                <Link key={n.href} href={n.href} className="hover:underline underline-offset-4">
                  {n.label}
                </Link>
              ))}
            </nav>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-4 py-10">{children}</main>

        <footer className="border-t mt-16">
          <div className="mx-auto max-w-6xl px-4 py-8 text-sm text-neutral-600 space-y-2">
            <p>{siteCopy.footer.disclaimer}</p>
            <p>{siteCopy.footer.copyright}</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
