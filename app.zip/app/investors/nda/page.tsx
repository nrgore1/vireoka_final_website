"use client";

import { useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

const NDA_TEXT = `
VIREOKA INVESTOR NDA (Summary)
- You will receive access to confidential investor materials.
- You agree not to share, copy, record, or distribute any confidential content.
- You agree not to reverse engineer or attempt to infer implementation details.
- Access is time-bound and revocable.
- Full NDA text should be provided by counsel for production use.
`;

export default function InvestorNdaPage() {
  const r = useRouter();
  const sp = useSearchParams();
  const email = useMemo(() => sp.get("email") || "", [sp]);
  const [checked, setChecked] = useState(false);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function accept() {
    setErr(null);
    setLoading(true);

    const res = await fetch("/api/investors/nda", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, accept: true }),
    });

    const data = await res.json().catch(() => ({}));
    setLoading(false);

    if (!res.ok) {
      setErr(data?.error || "Unable to record NDA acceptance.");
      return;
    }

    r.push("/investors/pending?ok=nda_recorded");
  }

  return (
    <div>
      <div className="badge">NDA</div>
      <h1 className="h1">Accept NDA to proceed</h1>
      <p className="p">
        We keep public materials high-level. NDA acceptance is required before your application can be reviewed.
      </p>

      <label className="label">Email on application</label>
      <input className="input" value={email} readOnly />

      <div className="card" style={{ marginTop: 14 }}>
        <h3>NDA summary (for demo)</h3>
        <p style={{ whiteSpace: "pre-wrap" }}>{NDA_TEXT}</p>
        <p className="small">
          Production: replace this with counsel-approved NDA text + e-sign workflow.
        </p>
      </div>

      <div style={{ marginTop: 12 }}>
        <label className="small" style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <input type="checkbox" checked={checked} onChange={(e) => setChecked(e.target.checked)} />
          I accept the NDA terms for investor access
        </label>
      </div>

      {err ? <p className="small" style={{ color: "#ffb4b4" }}>{err}</p> : null}

      <div style={{ marginTop: 12, display: "flex", gap: 10, flexWrap: "wrap" }}>
        <button className="btn" disabled={!checked || loading} onClick={accept}>
          {loading ? "Recording..." : "Accept NDA"}
        </button>
        <a className="btnSecondary" href="/investors">Cancel</a>
      </div>
    </div>
  );
}
