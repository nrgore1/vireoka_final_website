"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";

export default function InvestorPendingPage() {
  const sp = useSearchParams();
  const ok = sp.get("ok");
  const [email, setEmail] = useState("");
  const [result, setResult] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  async function check() {
    setErr(null);
    setResult(null);

    const res = await fetch("/api/investors/status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setErr(data?.error || "Unable to check status.");
      return;
    }
    setResult(data);
  }

  return (
    <div>
      <div className="badge">Status</div>
      <h1 className="h1">Check investor access status</h1>
      <p className="p">
        {ok === "nda_recorded"
          ? "NDA acceptance recorded. Your request is now ready for manual review."
          : "Enter the email you applied with to check status and access expiry."}
      </p>

      <label className="label">Email</label>
      <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} />

      <div style={{ marginTop: 12 }}>
        <button className="btn" onClick={check}>Check status</button>
        <a className="btnSecondary" style={{ marginLeft: 10 }} href="/investors">Back</a>
      </div>

      {err ? <p className="small" style={{ color: "#ffb4b4" }}>{err}</p> : null}

      {result ? (
        <div className="card" style={{ marginTop: 14 }}>
          <h3>Status</h3>
          <p className="small" style={{ whiteSpace: "pre-wrap" }}>
{JSON.stringify(result, null, 2)}
          </p>
          {result.status === "APPROVED" ? (
            <div style={{ marginTop: 10 }}>
              <a className="btn" href="/investors/approved">Continue</a>
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
