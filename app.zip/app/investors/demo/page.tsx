import { getInvestorFromCookie } from "@/lib/investorAuth";

export default async function InvestorDemoPage() {
  const investor = await getInvestorFromCookie();
  if (!investor) {
    return (
      <div>
        <div className="badge">Investor Demo</div>
        <h1 className="h1">Access required</h1>
        <p className="p">Your access is missing, expired, or not approved.</p>
        <a className="btn" href="/investors">Return to Investors</a>
      </div>
    );
  }

  return (
    <div>
      <div className="badge">Investor Demo (NDA)</div>
      <h1 className="h1">Welcome, approved investor</h1>
      <p className="p">
        This area intentionally avoids implementation-level IP. It provides a controlled overview,
        demo navigation, and gated documentation.
      </p>

      <div className="grid">
        <div className="card">
          <h3>Demo navigation</h3>
          <p>
            Provide a guided walkthrough (screenshots/video) of the Governance UI here.
            Keep visuals intentionally cropped and watermark them in production.
          </p>
        </div>
        <div className="card">
          <h3>NDA Investor Whitepaper</h3>
          <p>
            A deeper explanation aligned with Cognitive Governance, still avoiding code-level disclosures.
          </p>
          <div style={{ marginTop: 10 }}>
            <a className="btnSecondary" href="/api/investors/nda?doc=investor_whitepaper">Download (server gated)</a>
          </div>
        </div>
        <div className="card">
          <h3>Access window</h3>
          <p>
            Expires at: <b>{investor.expiresAt ? investor.expiresAt.toISOString() : "not set"}</b>
          </p>
          <p className="small">
            Email: {investor.email}<br/>
            Org: {investor.org}<br/>
            Status: {investor.status}
          </p>
        </div>
        <div className="card">
          <h3>Contact</h3>
          <p>For diligence questions, request a live demo session. Do not share screenshots externally.</p>
        </div>
      </div>
    </div>
  );
}
