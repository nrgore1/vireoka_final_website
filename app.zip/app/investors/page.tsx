import Link from "next/link";

export default function InvestorsLandingPage({
  searchParams,
}: {
  searchParams?: Record<string, string | string[] | undefined>;
}) {
  const reason = typeof searchParams?.reason === "string" ? searchParams?.reason : "";
  return (
    <div>
      <div className="badge">Investors</div>
      <h1 className="h1">NDA-gated access to the investor demo.</h1>
      <p className="p">
        To protect confidential IP, investor materials require an application, NDA acceptance,
        and manual approval. Approved access is time-bound.
      </p>

      {reason ? (
        <p className="small">
          Note: access required ({reason}). Please apply or check your status.
        </p>
      ) : null}

      <div className="grid">
        <div className="card">
          <h3>Apply</h3>
          <p>Submit your details. You will be directed to review and accept the NDA.</p>
          <div style={{ marginTop: 10 }}>
            <Link className="btn" href="/investors/apply">Start application</Link>
          </div>
        </div>

        <div className="card">
          <h3>Check Status</h3>
          <p>Use the same email you applied with to check approval and expiry.</p>
          <div style={{ marginTop: 10 }}>
            <Link className="btnSecondary" href="/investors/pending">Check status</Link>
          </div>
        </div>
      </div>

      <hr className="hr" />

      <p className="small">
        Public materials: <Link href="/resources">Resources</Link> •
        This flow enforces: application → NDA → approval → expiry.
      </p>
    </div>
  );
}
