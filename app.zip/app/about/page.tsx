export default function AboutPage() {
  return (
    <div>
      <div className="badge">About Vireoka</div>
      <h1 className="h1">A trust-first platform for governing AI reasoning.</h1>

      <p className="p">
        AI adoption is accelerating — but high-stakes environments require more than model capability.
        They require accountability, defensibility, and controlled disclosure.
      </p>

      <h2 className="h2">Our position</h2>
      <p className="p">
        Vireoka is built around <b>Cognitive Governance</b>: governance of how intelligence reasons,
        not just the outputs it produces. This enables responsible AI use across strategic, regulated,
        and reputation-sensitive domains.
      </p>

      <h2 className="h2">What we do (high level)</h2>
      <div className="grid">
        <div className="card">
          <h3>Reasoning accountability</h3>
          <p>Make AI-assisted reasoning explainable and reviewable in a way stakeholders can trust.</p>
        </div>
        <div className="card">
          <h3>Controlled access</h3>
          <p>Separate public messaging from NDA-gated investor and enterprise materials.</p>
        </div>
        <div className="card">
          <h3>Governance posture</h3>
          <p>Trust principles: transparency, uncertainty disclosure, and audit-friendly documentation.</p>
        </div>
        <div className="card">
          <h3>Future-ready</h3>
          <p>A platform approach that supports evolving needs without forcing “one worldview” or “one answer.”</p>
        </div>
      </div>

      <hr className="hr" />

      <p className="small">
        Vireoka LLC • Public content is intentionally limited to protect confidential IP.
      </p>
    </div>
  );
}
